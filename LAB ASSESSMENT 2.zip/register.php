<html>
<head>
<style>
          body {
            background-color: powderblue;
        }
        h2 {
            color: black;
            text-align: center;
        }
       
        table{
            width: 95%;
            margin: 50px;
            border-collapse: collapse;
            border-radius: 25px;
            border: black;
            border-style: solid;
            }
        td{
            font-weight: bold;
        }
        
    </style>
    <title>Add Student</title>
</head>

<body>
    <h2>Fill in the form to add a new student</h2>
    <form action="register.php" method="POST">
        <label>Name:</label>
        <input type="text" name="name" required>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Phone Number:</label>
        <input type="text" name="phone" required>

        <label>Program/Course:</label>
        <input type="text" name="program" required>

        <label>College Dormitory:</label>
        <input type="text" name="dormitory" required>

        <button type="submit">Add Student</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        include "db_conn.php";
        
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $program = $_POST['program'];
        $dormitory = $_POST['dormitory'];

        $sql = "INSERT INTO users (name, email, phone, program, dormitory) VALUES ('$name', '$email', '$phone', '$program', '$dormitory')";

        if (mysqli_query($conn, $sql)) {
            echo "<p style='text-align:center;'>New student added successfully</p>";
        } else {
            echo "<p style='text-align:center; color: red;'>Error adding student: " . mysqli_error($conn) . "</p>";
        }
    }
    ?>

        <a href="view.php">Click to view the list of students</a>
    </div>
</body>