<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            background-color: powderblue;
        }
        h2 {
            color: white;
            text-align: center;
        }
        table {
            width: 95%;
            margin: 50px;
            border-collapse: collapse;
            border-radius: 25px;
            border: solid black;
        }
        td {
            font-weight: bold;
        }
    </style>
    <title>Edit Student Information</title>
</head>
<body>
    <h2>Edit Information</h2>

    <?php
    include "db_conn.php";

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "SELECT * FROM users WHERE id = '$id'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
    }
    ?>

<form action="update.php?id=<?php echo $row['id']; ?>" method="POST">
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo $row['name']; ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?php echo $row['email']; ?>" required>

        <label>Phone Number:</label>
        <input type="text" name="phone" value="<?php echo isset($row['phone']) ? $row['phone'] : ''; ?>" required>

        <label>Program/Course:</label>
        <input type="text" name="program" value="<?php echo isset($row['program']) ? $row['program'] : ''; ?>" required>

        <label>College Dormitory:</label>
        <input type="text" name="dormitory" value="<?php echo isset($row['dormitory']) ? $row['dormitory'] : ''; ?>" required>

        <button type="submit">Update User</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $program = $_POST['program'];
        $dormitory = $_POST['dormitory'];

        $sql = "UPDATE users SET name='$name', email='$email', phone='$phone', program='$program', dormitory='$dormitory' WHERE id=$id";

        if (mysqli_query($conn, $sql)) {
            echo "<p style='text-align:center;'>Record updated successfully</p>";
        } else {
            echo "<p style='text-align:center; color: red;'>Error updating record: " . mysqli_error($conn) . "</p>";
        }
    }
    ?>

    <br>
    <a href="view.php">Click to view the list of students</a>
</body>
</html>
