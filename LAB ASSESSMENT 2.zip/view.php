<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            background-color: powderblue;
        }
        h2 {
            color: black;
            text-align: center;
        }
        table {
            width: 95%;
            margin: 50px auto;
            border-collapse: collapse;
            border-radius: 25px;
            border:  solid black;
        }
        td {
            font-weight: bold;
            text-align: center;
            padding: 8px;
        }

        img {
            width: 80%; 
            height: auto; 
            display: block; 
        }
    </style>
    <title>STUDENT REGISTRATION FORM</title>
</head>

<body>
    <h2>STUDENT REGISTRATION FORM</h2>
    <img src="welcome.png" alt="welcoming image">
    <h3>Welcome to the Student Registration Portal</h3>
    
    <p>We’re excited to have you join our academic community! Please take a few moments to complete your registration. 
       This form will collect essential information about you, including contact details, chosen program, and accommodations. 
       Your details will help us ensure that you have the resources and support you need throughout your studies.</p>
    
    <table border="1">
        <tr>
            <td>ID</td>
            <td>Name</td>
            <td>Email</td>
            <td>Phone Number</td>
            <td>Program/Course</td>
            <td>College Dormitory</td>
            <td>Edit</td>
            <td>Delete</td> 
        </tr>
        
        <?php
include "db_conn.php"; 

$sql = "SELECT * FROM users";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . (isset($row["id"]) ? $row["id"] : "") . "</td>";
        echo "<td>" . (isset($row["name"]) ? $row["name"] : "") . "</td>";
        echo "<td>" . (isset($row["email"]) ? $row["email"] : "") . "</td>";
        echo "<td>" . (isset($row["phone"]) ? $row["phone"] : "") . "</td>";
        echo "<td>" . (isset($row["program"]) ? $row["program"] : "") . "</td>";
        echo "<td>" . (isset($row["dormitory"]) ? $row["dormitory"] : "") . "</td>";
        echo "<td><a href='update.php?id=" . $row['id'] . "'>Edit</a></td>";
        echo "<td><a href='delete.php?id=" . $row['id'] . "'>Delete</a></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='8'>No Data Found</td></tr>";
}
?>

    </table>
    <br>
    <div style="text-align: center;">
        <a href="register.php">Click to fill in registration form</a>
    </div>
</body>
</html>
